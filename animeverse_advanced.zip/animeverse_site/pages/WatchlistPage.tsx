import React from 'react';
import { Link } from 'react-router-dom';
import AnimeCard from '../components/AnimeCard';
import WatchlistButton from '../components/WatchlistButton';
import { useWatchlist } from '../contexts/WatchlistContext';

/**
 * Displays all anime that the user has added to their watchlist.  If the
 * watchlist is empty a helpful message is shown instead.  Each card
 * includes a button to remove the anime from the watchlist directly.
 */
const WatchlistPage: React.FC = () => {
  const { watchlist } = useWatchlist();
  return (
    <div className="pt-28 container mx-auto px-4 sm:px-6 lg:px-8 pb-12 min-h-screen">
      <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">لیست تماشا</h2>
      {watchlist.length === 0 ? (
        <p className="text-gray-400">لیست تماشا خالی است. انیمه‌ای را به لیست خود اضافه کنید!</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
          {watchlist.map((anime) => (
            <div key={anime.id} className="relative group">
              <Link to={`/anime/${anime.id}`} className="block h-full">
                <AnimeCard anime={anime} />
              </Link>
              <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                <WatchlistButton anime={anime} size="w-6 h-6" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WatchlistPage;