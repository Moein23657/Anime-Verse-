import React, { createContext, useState, useEffect, useContext } from 'react';
import { Anime } from '../types';

/**
 * WatchlistContext provides a global store for a user's watchlist.  It allows
 * components throughout the app to check whether a specific anime is in the
 * watchlist, toggle its inclusion, and access the full list.  The watchlist
 * is persisted to localStorage so it survives page reloads.
 */
export interface WatchlistContextValue {
  watchlist: Anime[];
  toggleWatchlist: (anime: Anime) => void;
  isInWatchlist: (anime: Anime) => boolean;
}

const defaultValue: WatchlistContextValue = {
  watchlist: [],
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  toggleWatchlist: () => {},
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  isInWatchlist: () => false,
};

export const WatchlistContext = createContext<WatchlistContextValue>(defaultValue);

export const WatchlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [watchlist, setWatchlist] = useState<Anime[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem('animeWatchlist');
        return stored ? (JSON.parse(stored) as Anime[]) : [];
      } catch {
        return [];
      }
    }
    return [];
  });

  // Persist watchlist to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('animeWatchlist', JSON.stringify(watchlist));
    } catch {
      // ignore persistence errors
    }
  }, [watchlist]);

  const toggleWatchlist = (anime: Anime) => {
    setWatchlist((current) => {
      const exists = current.some((a) => a.id === anime.id);
      if (exists) {
        return current.filter((a) => a.id !== anime.id);
      }
      return [...current, anime];
    });
  };

  const isInWatchlist = (anime: Anime) => watchlist.some((a) => a.id === anime.id);

  return (
    <WatchlistContext.Provider value={{ watchlist, toggleWatchlist, isInWatchlist }}>
      {children}
    </WatchlistContext.Provider>
  );
};

/**
 * Custom hook for convenience so components don't need to import
 * useContext and WatchlistContext separately.
 */
export const useWatchlist = () => useContext(WatchlistContext);