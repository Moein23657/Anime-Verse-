
import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import { Anime } from './types';
import { MOCK_ANIME_DATA } from './constants';
import AnimeCarousel from './components/AnimeCarousel';
import AnimeCard from './components/AnimeCard';
import {
  SearchIcon,
  StarIcon,
  DownloadIcon,
  ChevronLeftIcon,
  PlayIcon,
  SparklesIcon,
  HeartIcon,
} from './components/icons';
import RecommendationEngine from './components/RecommendationEngine';
import WatchlistPage from './pages/WatchlistPage';
import { useWatchlist } from './contexts/WatchlistContext';
import GenreFilter from './components/GenreFilter';
import WatchlistButton from './components/WatchlistButton';

const Header: React.FC<{ onSearch: (term: string) => void }> = ({ onSearch }) => {
  const { watchlist } = useWatchlist();
  return (
    <header className="fixed top-0 right-0 left-0 z-50 bg-black/30 backdrop-blur-lg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-8 space-x-reverse">
            <Link to="/" className="text-3xl font-extrabold text-white">
              <span className="text-fuchsia-500">Anime</span>Verse
            </Link>
            <nav className="hidden md:flex items-center space-x-6 space-x-reverse">
              <Link to="/" className="text-gray-300 hover:text-white transition-colors font-medium">خانه</Link>
              <Link to="/recommendations" className="flex items-center text-gray-300 hover:text-white transition-colors font-medium">
                <SparklesIcon className="w-5 h-5 ml-2 text-fuchsia-400" />
                پیشنهاد هوشمند
              </Link>
              <Link to="/watchlist" className="relative flex items-center text-gray-300 hover:text-white transition-colors font-medium">
                <HeartIcon className="w-5 h-5 ml-2" filled={watchlist.length > 0} />
                لیست تماشا
                {watchlist.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-fuchsia-600 text-white text-xs font-bold rounded-full px-1.5 py-0.5">
                    {watchlist.length}
                  </span>
                )}
              </Link>
            </nav>
          </div>
          <div className="relative w-full max-w-xs">
            <input
              type="text"
              placeholder="جستجو انیمه..."
              onChange={(e) => onSearch(e.target.value)}
              className="w-full bg-gray-800/50 text-white placeholder-gray-400 border-2 border-transparent focus:border-fuchsia-500 focus:ring-0 rounded-full py-2 px-4 pr-10 transition-all"
            />
            <SearchIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          </div>
        </div>
      </div>
    </header>
  );
};

const HeroSection: React.FC<{ anime: Anime }> = ({ anime }) => (
  <div className="relative h-[60vh] md:h-[80vh] w-full flex items-end text-white p-4 md:p-12">
    <div className="absolute inset-0">
      <img src={anime.backdrop} alt={anime.title} className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-gray-950 to-transparent opacity-50"></div>
    </div>
    <div className="relative z-10 max-w-2xl">
      <h1 className="text-4xl md:text-6xl font-black drop-shadow-lg">{anime.title}</h1>
      <div className="flex items-center my-4 space-x-4 space-x-reverse">
        <div className="flex items-center">
          <StarIcon className="w-5 h-5 text-yellow-400 ml-1" />
          <span className="font-bold text-lg">{anime.rating}</span>
        </div>
        <span className="text-gray-300">{anime.year}</span>
        <span className="border border-gray-400 rounded-md px-2 py-0.5 text-sm">{anime.status}</span>
      </div>
      <p className="text-gray-200 text-sm md:text-base leading-relaxed hidden md:block">{anime.synopsis.substring(0, 150)}...</p>
      <Link to={`/anime/${anime.id}`} className="mt-6 inline-flex items-center bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white font-bold py-3 px-8 rounded-full hover:from-fuchsia-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg">
        <PlayIcon className="w-6 h-6 ml-2" />
        مشاهده و دانلود
      </Link>
    </div>
  </div>
);


const AnimeDetailView: React.FC<{ anime: Anime; onBack: () => void }> = ({ anime, onBack }) => {
    const [downloading, setDownloading] = useState<number | null>(null);

    const handleDownload = (episodeNumber: number) => {
        setDownloading(episodeNumber);
        setTimeout(() => {
            alert(`دانلود قسمت ${episodeNumber} از انیمه ${anime.title} شروع شد! (شبیه‌سازی)`);
            setDownloading(null);
        }, 1500);
    };
    
    return (
    <div className="min-h-screen bg-gray-950 text-white pt-20 animate-fade-in">
        <div className="relative h-[50vh]">
            <img src={anime.backdrop} alt="" className="absolute inset-0 w-full h-full object-cover opacity-30"/>
            <div className="absolute inset-0 bg-gradient-to-t from-gray-950 to-transparent"></div>
        </div>

        <div className="container mx-auto p-4 sm:p-6 lg:p-8 -mt-48 relative z-10">
            <button onClick={onBack} className="absolute top-0 right-4 md:right-0 bg-white/10 backdrop-blur-md p-2 rounded-full hover:bg-white/20 transition-all">
                <ChevronLeftIcon className="w-6 h-6 transform -rotate-180" />
            </button>
            <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/3 flex-shrink-0">
                    <img src={anime.poster} alt={anime.title} className="rounded-xl shadow-2xl shadow-fuchsia-900/20 w-full"/>
                </div>
                <div className="md:w-2/3">
                    <h1 className="text-4xl md:text-5xl font-black mb-2">{anime.title}</h1>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mb-4 text-gray-300">
                        <div className="flex items-center"><StarIcon className="w-5 h-5 text-yellow-400 ml-1.5"/>{anime.rating}</div>
                        <span>{anime.year}</span>
                        <span>{anime.status}</span>
                        {/* Add watchlist toggle for detail view */}
                        <div className="ml-auto">
                          <WatchlistButton anime={anime} size="w-8 h-8" />
                        </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-6">
                        {anime.genres.map(g => <span key={g} className="bg-gray-800 text-gray-300 text-xs font-semibold px-3 py-1 rounded-full">{g}</span>)}
                    </div>
                    <p className="leading-loose text-gray-300">{anime.synopsis}</p>
                </div>
            </div>

            <div className="mt-12">
                <h2 className="text-3xl font-bold mb-6 pr-4 border-r-4 border-fuchsia-500">قسمت‌ها</h2>
                <div className="space-y-3">
                    {anime.episodes.map(ep => (
                        <div key={ep.number} className="flex items-center justify-between bg-gradient-to-r from-gray-900 to-gray-800/50 p-4 rounded-lg border border-gray-700 hover:border-fuchsia-500 hover:shadow-lg hover:shadow-fuchsia-500/10 transition-all duration-300">
                            <div className="flex items-center">
                                <span className="text-fuchsia-400 font-bold text-lg w-8 text-center">{ep.number}</span>
                                <span className="mr-4 text-gray-200">{ep.title}</span>
                            </div>
                            <div className="flex items-center space-x-4 space-x-reverse">
                                <span className="text-sm text-gray-400 hidden sm:block">{ep.duration}</span>
                                <button
                                    onClick={() => handleDownload(ep.number)}
                                    disabled={downloading === ep.number}
                                    className="flex items-center justify-center w-28 bg-transparent border-2 border-fuchsia-500 text-fuchsia-400 font-semibold py-2 px-4 rounded-md hover:bg-fuchsia-500 hover:text-white transition-all disabled:bg-gray-700 disabled:border-gray-700 disabled:text-gray-400 disabled:cursor-not-allowed"
                                >
                                    {downloading === ep.number ? (
                                        <div className="w-5 h-5 border-2 border-t-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                    ) : (
                                        <>
                                            <DownloadIcon className="w-5 h-5 ml-2"/>
                                            <span>دانلود</span>
                                        </>
                                    )}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    </div>
    );
};

const AnimeDetailPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const anime = MOCK_ANIME_DATA.find(a => a.id === Number(id));

    useEffect(() => {
      window.scrollTo(0, 0);
    }, [id]);

    if (!anime) {
        return <div className="text-white text-center pt-28">انیمه یافت نشد.</div>;
    }

    return <AnimeDetailView anime={anime} onBack={() => navigate(-1)} />;
};

const HomePage: React.FC<{ searchTerm: string; filteredAnimes: Anime[] }> = ({ searchTerm, filteredAnimes }) => {
  // Determine hero and curated lists from all mock data
  const trendingAnimes = React.useMemo(() => [...MOCK_ANIME_DATA].sort((a, b) => b.rating - a.rating), []);
  const recentAnimes = React.useMemo(() => [...MOCK_ANIME_DATA].sort((a, b) => b.year - a.year), []);
  const actionAnimes = React.useMemo(() => MOCK_ANIME_DATA.filter((anime) => anime.genres.includes('اکشن')), []);
  const heroAnime = MOCK_ANIME_DATA[0];

  // Gather all unique genres for the filter
  const allGenres = React.useMemo(() => {
    const set = new Set<string>();
    MOCK_ANIME_DATA.forEach((anime) => {
      anime.genres.forEach((g) => set.add(g));
    });
    return Array.from(set);
  }, []);

  // Selected genre state.  When null no filtering is applied.
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);

  // Determine which animes to show based on search and genre filters
  const displayAnimes = React.useMemo(() => {
    if (!searchTerm) {
      return [];
    }
    if (selectedGenre) {
      return filteredAnimes.filter((anime) => anime.genres.includes(selectedGenre));
    }
    return filteredAnimes;
  }, [filteredAnimes, searchTerm, selectedGenre]);

  return (
    <main>
      {searchTerm ? (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-28">
          <h2 className="text-2xl font-bold text-white mb-6">
            نتایج جستجو برای "{searchTerm}"
          </h2>
          {/* Genre filter is only shown when a search term is entered */}
          {filteredAnimes.length > 0 && (
            <GenreFilter
              genres={allGenres}
              selectedGenre={selectedGenre}
              onSelect={setSelectedGenre}
            />
          )}
          {displayAnimes.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
              {displayAnimes.map((anime) => (
                <div key={anime.id} className="aspect-[2/3] relative">
                  <Link to={`/anime/${anime.id}`} className="block h-full">
                    <AnimeCard anime={anime} />
                  </Link>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 text-center py-10">هیچ انیمه‌ای یافت نشد.</p>
          )}
        </div>
      ) : (
        <>
          <HeroSection anime={heroAnime} />
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <AnimeCarousel title="محبوب‌ترین‌ها" animes={trendingAnimes} />
            <AnimeCarousel title="تازه‌ترین‌ها" animes={recentAnimes} />
            <AnimeCarousel
              title="پر از اکشن"
              animes={actionAnimes}
              backgroundColor="rgba(40, 20, 80, 0.3)"
              fontSize="2.5rem"
            />
          </div>
        </>
      )}
    </main>
  );
};


const App: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredAnimes, setFilteredAnimes] = useState(MOCK_ANIME_DATA);

  useEffect(() => {
    // Perform a comprehensive search across title, synopsis and genres.  If
    // multiple terms are provided separated by spaces, all must match for the
    // anime to be included.  The search is case-insensitive and supports
    // Persian and Latin characters.
    const term = searchTerm.trim().toLowerCase();
    if (!term) {
      setFilteredAnimes(MOCK_ANIME_DATA);
      return;
    }
    const tokens = term.split(/\s+/);
    const results = MOCK_ANIME_DATA.filter((anime) => {
      const haystack = [anime.title, anime.synopsis, ...anime.genres]
        .join(' ')  // join fields to one string
        .toLowerCase();
      return tokens.every((tk) => haystack.includes(tk));
    });
    setFilteredAnimes(results);
  }, [searchTerm]);

  return (
    <div className="bg-gray-950 min-h-screen">
      <Header onSearch={setSearchTerm} />
      <Routes>
        <Route path="/" element={<HomePage searchTerm={searchTerm} filteredAnimes={filteredAnimes} />} />
        <Route path="/anime/:id" element={<AnimeDetailPage />} />
        <Route
          path="/recommendations"
          element={
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-12">
              <RecommendationEngine />
            </div>
          }
        />
        <Route path="/watchlist" element={<WatchlistPage />} />
      </Routes>
      <footer className="bg-gray-900/50 text-center py-6 text-gray-400 text-sm">
        <p>ساخته شده با ❤️ برای طرفداران انیمه.</p>
        <p>&copy; {new Date().getFullYear()} AnimeVerse. تمامی حقوق محفوظ است.</p>
      </footer>
    </div>
  );
};

export default App;
