
import { GoogleGenAI, Type } from "@google/genai";
import { RecommendedAnime } from '../types';

export const getAnimeRecommendations = async (
  favoriteAnimes: string
): Promise<RecommendedAnime[]> => {
  try {
    // Determine API key from environment.  Prefer GEMINI_API_KEY but fall back
    // to API_KEY for backwards compatibility.  If no key is provided the
    // request will fail and the caller will receive an error.
    const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY || '';
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `بر اساس انیمه‌های زیر، ۵ انیمه دیگر با تم، سبک هنری یا ژانر مشابه پیشنهاد بده. عنوان، یک خلاصه یک جمله‌ای و ژانر اصلی را برای هر کدام ارائه بده. انیمه‌های ورودی: ${favoriteAnimes}`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: {
                type: Type.STRING,
                description: 'عنوان انیمه پیشنهادی',
              },
              synopsis: {
                type: Type.STRING,
                description: 'خلاصه یک جمله‌ای از انیمه',
              },
              genre: {
                type: Type.STRING,
                description: 'ژانر اصلی انیمه',
              },
            },
            required: ['title', 'synopsis', 'genre'],
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const recommendations = JSON.parse(jsonText);
    return recommendations as RecommendedAnime[];
  } catch (error) {
    console.error('Error getting recommendations from Gemini API:', error);
    throw new Error('متاسفانه در دریافت پیشنهادات مشکلی پیش آمد.');
  }
};
