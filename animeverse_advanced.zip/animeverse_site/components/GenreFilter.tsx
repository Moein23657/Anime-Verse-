import React from 'react';

/**
 * GenreFilter renders a list of genre buttons allowing users to filter
 * anime by their primary genre.  It also includes a button to clear the
 * selection.  When a genre is selected it is highlighted; clicking the
 * same genre again clears the filter.
 */
export interface GenreFilterProps {
  /** List of unique genres available in the catalogue */
  genres: string[];
  /** Currently selected genre, or null if no genre is selected */
  selectedGenre: string | null;
  /** Called when the user selects or clears a genre */
  onSelect: (genre: string | null) => void;
}

const GenreFilter: React.FC<GenreFilterProps> = ({ genres, selectedGenre, onSelect }) => {
  return (
    <div className="flex flex-wrap gap-3 mb-6">
      <button
        onClick={() => onSelect(null)}
        className={`px-3 py-1 text-xs sm:text-sm rounded-full border transition-colors ${selectedGenre === null ? 'bg-fuchsia-600 border-fuchsia-600 text-white' : 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-fuchsia-700 hover:border-fuchsia-700 hover:text-white'}`}
      >
        همه
      </button>
      {genres.map((g) => (
        <button
          key={g}
          onClick={() => onSelect(selectedGenre === g ? null : g)}
          className={`px-3 py-1 text-xs sm:text-sm rounded-full border transition-colors ${selectedGenre === g ? 'bg-fuchsia-600 border-fuchsia-600 text-white' : 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-fuchsia-700 hover:border-fuchsia-700 hover:text-white'}`}
        >
          {g}
        </button>
      ))}
    </div>
  );
};

export default GenreFilter;