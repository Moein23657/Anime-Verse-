
import React from 'react';
import { Anime } from '../types';
import { StarIcon } from './icons';
import WatchlistButton from './WatchlistButton';

interface AnimeCardProps {
  anime: Anime;
}

const AnimeCard: React.FC<AnimeCardProps> = ({ anime }) => {
  return (
    <div
      className="group relative h-full w-full cursor-pointer overflow-hidden rounded-xl shadow-lg transition-all duration-300 ease-in-out hover:scale-105 hover:shadow-2xl hover:shadow-fuchsia-500/30"
    >
      <img
        src={anime.poster}
        alt={anime.title}
        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
      />
      {/* Dark gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
      {/* Watchlist toggle (appears on hover) */}
      <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
        <WatchlistButton anime={anime} size="w-6 h-6" />
      </div>
      {/* Metadata */}
      <div className="absolute bottom-0 right-0 p-4 text-white">
        <h3 className="text-lg font-bold drop-shadow-lg">{anime.title}</h3>
        <div className="flex items-center mt-1 text-sm">
          <StarIcon className="w-4 h-4 text-yellow-400 ml-1" />
          <span>{anime.rating}</span>
          <span className="mx-2">|</span>
          <span>{anime.year}</span>
        </div>
      </div>
    </div>
  );
};

export default AnimeCard;