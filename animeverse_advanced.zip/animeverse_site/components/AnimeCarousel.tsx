
import React from 'react';
import { Link } from 'react-router-dom';
import { Anime } from '../types';
import AnimeCard from './AnimeCard';

interface AnimeCarouselProps {
  title: string;
  animes: Anime[];
  backgroundColor?: string;
  fontSize?: string;
}

const AnimeCarousel: React.FC<AnimeCarouselProps> = ({ title, animes, backgroundColor, fontSize }) => {
  const containerStyle: React.CSSProperties = {};
  if (backgroundColor) {
    containerStyle.backgroundColor = backgroundColor;
  }

  const titleStyle: React.CSSProperties = {};
  if (fontSize) {
    titleStyle.fontSize = fontSize;
  }

  return (
    <div
      className={`mb-12 transition-colors duration-300 ${backgroundColor ? 'p-6 rounded-2xl' : ''}`}
      style={containerStyle}
    >
      <h2
        className="text-2xl md:text-3xl font-bold text-white mb-6 pr-4 border-r-4 border-fuchsia-500"
        style={titleStyle}
      >
        {title}
      </h2>
      <div className="flex space-x-6 space-x-reverse overflow-x-auto pb-4 px-4 -mx-4 scrollbar-thin scrollbar-thumb-fuchsia-700 scrollbar-track-gray-800">
        {animes.map((anime) => (
          <div key={anime.id} className="flex-shrink-0 w-48 md:w-60">
             <Link to={`/anime/${anime.id}`} className="block h-full w-full">
                <AnimeCard anime={anime} />
             </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AnimeCarousel;