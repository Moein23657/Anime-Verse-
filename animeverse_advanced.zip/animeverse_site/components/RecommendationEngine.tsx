
import React, { useState } from 'react';
import { getAnimeRecommendations } from '../services/geminiService';
import { RecommendedAnime } from '../types';
import Loader from './Loader';
import { SparklesIcon } from './icons';

const RecommendationEngine: React.FC = () => {
  const [favorites, setFavorites] = useState('');
  const [recommendations, setRecommendations] = useState<RecommendedAnime[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGetRecommendations = async () => {
    if (!favorites.trim()) {
      setError('لطفاً حداقل یک انیمه وارد کنید.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setRecommendations([]);

    try {
      const result = await getAnimeRecommendations(favorites);
      setRecommendations(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطای ناشناخته');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="my-16 p-6 md:p-8 rounded-2xl bg-gray-800/50 backdrop-blur-lg border border-fuchsia-500/20 shadow-xl">
      <div className="flex items-center mb-6">
        <SparklesIcon className="w-8 h-8 text-fuchsia-400 ml-3" />
        <h2 className="text-2xl md:text-3xl font-bold text-white">پیشنهاد هوشمند برای شما</h2>
      </div>
      <p className="text-gray-300 mb-6">
        انیمه‌های مورد علاقه خود را (با کاما جدا کنید) وارد کنید تا هوش مصنوعی ما بهترین پیشنهادات را برای شما پیدا کند!
      </p>
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <textarea
          value={favorites}
          onChange={(e) => setFavorites(e.target.value)}
          placeholder="مثال: Attack on Titan, Death Note, Steins;Gate"
          className="flex-grow bg-gray-900/70 border-2 border-gray-700 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-fuchsia-500 focus:border-transparent transition-all"
          rows={2}
        />
        <button
          onClick={handleGetRecommendations}
          disabled={isLoading}
          className="flex-shrink-0 bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white font-bold py-3 px-6 rounded-lg hover:from-fuchsia-700 hover:to-purple-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg"
        >
          {isLoading ? 'در حال پردازش...' : 'دریافت پیشنهادات'}
        </button>
      </div>

      {error && <p className="text-red-400 text-center mb-4">{error}</p>}
      
      {isLoading && <Loader text="هوش مصنوعی در حال یافتن بهترین‌هاست..." />}

      {recommendations.length > 0 && (
        <div>
            <h3 className="text-xl font-bold text-white mb-4">نتایج یافت شده:</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recommendations.map((rec, index) => (
                    <div key={index} className="bg-gray-900/60 p-5 rounded-lg border border-gray-700 hover:border-fuchsia-500 transition-all transform hover:-translate-y-1">
                        <h4 className="text-lg font-bold text-fuchsia-400 mb-2">{rec.title}</h4>
                        <p className="text-sm text-gray-300 mb-3">{rec.synopsis}</p>
                        <span className="text-xs font-semibold bg-gray-700 text-gray-200 px-2 py-1 rounded-full">{rec.genre}</span>
                    </div>
                ))}
            </div>
        </div>
      )}
    </div>
  );
};

export default RecommendationEngine;
