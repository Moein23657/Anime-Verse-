import React from 'react';
import { Anime } from '../types';
import { useWatchlist } from '../contexts/WatchlistContext';
import { HeartIcon } from './icons';

/**
 * A small button used to add or remove an anime from the user's watchlist.
 * It renders a heart icon that is filled when the anime is already in the
 * watchlist.  Clicking the button toggles the anime's presence.  The
 * component accepts optional `className` and `size` props to allow styling
 * flexibility.
 */
interface WatchlistButtonProps {
  anime: Anime;
  /** Additional Tailwind class names to apply to the button wrapper */
  className?: string;
  /** Tailwind classes to control the size of the heart icon (e.g. `w-6 h-6`) */
  size?: string;
}

const WatchlistButton: React.FC<WatchlistButtonProps> = ({ anime, className = '', size = 'w-6 h-6' }) => {
  const { toggleWatchlist, isInWatchlist } = useWatchlist();
  const inList = isInWatchlist(anime);
  return (
    <button
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleWatchlist(anime);
      }}
      title={inList ? 'حذف از لیست تماشا' : 'افزودن به لیست تماشا'}
      className={`focus:outline-none ${className}`}
    >
      <HeartIcon
        filled={inList}
        className={`${size} ${inList ? 'text-fuchsia-500' : 'text-gray-400'} hover:text-fuchsia-400 transition-colors`}
      />
    </button>
  );
};

export default WatchlistButton;