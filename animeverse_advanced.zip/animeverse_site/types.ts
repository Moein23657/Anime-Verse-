
export interface Episode {
  number: number;
  title: string;
  duration: string;
}

export interface Anime {
  id: number;
  title: string;
  poster: string;
  backdrop: string;
  genres: string[];
  rating: number;
  year: number;
  status: 'درحال پخش' | 'پایان یافته';
  episodes: Episode[];
  synopsis: string;
}

export interface RecommendedAnime {
  title: string;
  synopsis: string;
  genre: string;
}
